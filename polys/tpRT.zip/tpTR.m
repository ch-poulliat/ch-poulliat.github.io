close all;
clear all;

%Performance D�codage MAP d'un code convolutif

    %Simulation parameters
    EbN0dB=[0:6];
    N= 4096;
    M=2;
    MC=100000000;
    %Coding parameters
    hConEnc = comm.ConvolutionalEncoder('TerminationMethod','Truncated');
    hMod = comm.PSKModulator('ModulationOrder',2,'BitInput',true, 'PhaseOffset',0);
    R=1/2;
    
              
    %decoding parameters
    hAPPDec = comm.APPDecoder(...
               'TrellisStructure', poly2trellis(7, [171 133]), ...
               'Algorithm', 'True APP', 'CodedBitLLROutputPort', false);
    hVITDec = comm.ViterbiDecoder('InputFormat','Unquantized', 'TerminationMethod','Truncated' );
    %handling errour count       
    hErrorMAP = comm.ErrorRate;
    hErrorML = comm.ErrorRate;

    %Allocation
    BER_ML=zeros(1,length(EbN0dB));
    BER_MAP=zeros(1,length(EbN0dB));
   
    
    for ii=1:length(EbN0dB)
      
      
      %for mc=1:MC
      mc=0;
      NbErrorsML=0;
      
      while ((NbErrorsML <1000)||(mc<100))&&(mc<MC)    
      disp([ii,mc])
      %random data generation  
      data = randi([0 1],N,1);
      
      %encode convolutional codes
      encodedData = step(hConEnc, data);
      
      %Modulation
      modSignal = step(hMod, encodedData);
      
      %add noise
       EbN0=10^(EbN0dB(ii)/10);
       Px= mean(abs(modSignal).^2);
       sigma_2= Px/(2*log2(M)*R*(EbN0));
       noiseAWGN= sqrt(sigma_2)*randn(1,length(modSignal));
       receivedSignal = modSignal + noiseAWGN.';
      
      %Demod
       % Demodulate using soft decisions
      hDemod = comm.PSKDemodulator('ModulationOrder',2,'BitOutput',true, 'PhaseOffset',0, ...
               'DecisionMethod', 'Log-likelihood ratio', ...
               'Variance', 2*sigma_2);
      demodSignal = step(hDemod, receivedSignal);
      
      % Decode the convolutionally encoded data. The APP decoder assumes a
      % polarization of the soft inputs that is inverse to that of the 
      % demodulator soft outputs so change the sign of demodSignal
      receivedSoftBits = step(hAPPDec, zeros(N,1), -demodSignal);
      % Convert soft decisions to hard decisions
      receivedBitsMAP = double(receivedSoftBits > 0);
      
      errorStatsMAP= step(hErrorMAP, data, receivedBitsMAP);
      %ViterbiDecoder
      receivedBitsML=step(hVITDec, demodSignal);
      
      errorStatsML= step(hErrorML, data, receivedBitsML); 
      mc=mc+1;
      NbErrorsML=errorStatsML(2);
      end
      
      BER_MAP(ii)=errorStatsMAP(1);
      BER_ML(ii)=errorStatsML(1);
      
      reset(hErrorMAP);
      reset(hErrorML);
    end
    
    
    semilogy(EbN0dB,BER_MAP','ro-');
    hold on
    semilogy(EbN0dB,BER_ML','bx-');
   
    
   