%Turbo codes
   
%Simulation parameters
    EbN0dB=[0:6];
    N= 512;
    M=2;
    MC=100000000;
    ITERMAX=10;
    %Coding parameters
    hConEnc = comm.ConvolutionalEncoder('TrellisStructure', poly2trellis(3, ...
           [7 5],7),'TerminationMethod','Truncated');
    hConEnc2 = comm.ConvolutionalEncoder('TrellisStructure', poly2trellis(3, ...
           [7 5],7),'TerminationMethod','Truncated');
    hMod = comm.PSKModulator('ModulationOrder',2,'BitInput',true, 'PhaseOffset',0);
    R=1/2;
    
              
    %decoding parameters
    hAPPDec1 = comm.APPDecoder('TrellisStructure', poly2trellis(3, ...
           [7 5],7), ...
               'Algorithm', 'True APP', 'CodedBitLLROutputPort', false);
    hAPPDec2 = comm.APPDecoder('TrellisStructure', poly2trellis(3, ...
           [7 5],7), ...
               'Algorithm', 'True APP', 'CodedBitLLROutputPort', false);
           
    %Interleaver
    s = RandStream('mt19937ar', 'Seed', 11);
    intrlvrIndices = randperm(s, N)';
    
    
    %handling errour count       
    hErrorMAP = comm.ErrorRate;
    
    %Allocation
    BER_MAP=zeros(1,length(EbN0dB));
   
    
    for ii=1:length(EbN0dB)
      
      
      %for mc=1:MC
      mc=0;
      NbErrorsML=0;
      
      while ((NbErrorsML <1000)||(mc<100))&&(mc<MC)    
      disp([ii,mc])
      %random data generation  
      data = randi([0 1],N,1);
      %data=zeros(N,1);
      %encode turbo codes
      encodedData1 = step(hConEnc, data);
      encodedInterleavedData = step(hConEnc2, data(intrlvrIndices));
      parity2Interleadeddata=encodedInterleavedData(2:2:end);
      
      %Modulation
      modSignal = step(hMod, [encodedData1; parity2Interleadeddata]);
      
      %add noise
       EbN0=10^(EbN0dB(ii)/10);
       Px= mean(abs(modSignal).^2);
       sigma_2= Px/(2*log2(M)*R*(EbN0));
       noiseAWGN= sqrt(sigma_2)*randn(1,length(modSignal));
       receivedSignal = modSignal + noiseAWGN.';
      
      %Demod
       % Demodulate using soft decisions
      hDemod = comm.PSKDemodulator('ModulationOrder',2,'BitOutput',true, 'PhaseOffset',0, ...
               'DecisionMethod', 'Log-likelihood ratio', ...
               'Variance', 2*sigma_2);
      demodSignal = step(hDemod, receivedSignal);
      demodSignalDec1=[demodSignal(1:2*N)];
      demodsyst=demodSignal(1:2:2*N);
      demodSignalDec2=zeros([size(demodSignalDec1)])
      demodSignalDec2(1:2:end)=demodsyst(intrlvrIndices);
      demodSignalDec2(2:2:end)=demodSignal(2*N+1:end);
      
      % Decode the convolutionally encoded data. The APP decoder assumes a
      % polarization of the soft inputs that is inverse to that of the 
      % demodulator soft outputs so change the sign of demodSignal
      receivedSoftBits1 = step(hAPPDec1, zeros(N,1), -demodSignalDec1);
      La2=receivedSoftBits1+demodsyst;
      receivedSoftBits2 = step(hAPPDec2, La2(intrlvrIndices) , -demodSignalDec2);
      La1(intrlvrIndices)=receivedSoftBits2-La2(intrlvrIndices)+demodsyst(intrlvrIndices);
      for k=2:ITERMAX
          receivedSoftBits1 = step(hAPPDec1, La1', -demodSignalDec1);
          La2=receivedSoftBits1-La1'+demodsyst;
          receivedSoftBits2 = step(hAPPDec2, La2(intrlvrIndices) , -demodSignalDec2);
          La1(intrlvrIndices)=receivedSoftBits2-La2(intrlvrIndices)+demodsyst(intrlvrIndices);
          receivedBitsMAP = double((receivedSoftBits1+La1')> 0);
         sum(double((receivedSoftBits1+La1')> 0))
      end
      % Convert soft decisions to hard decisions
      receivedBitsMAP = double((receivedSoftBits1+La1')> 0);
      
      errorStatsMAP= step(hErrorMAP, data, receivedBitsMAP);
      %ViterbiDecoder
      receivedBitsML=step(hVITDec, demodSignal);
      
      %errorStatsML= step(hErrorML, data, receivedBitsML); 
      mc=mc+1;
      NbErrorsML=errorStatsML(2);
      end
      
      BER_MAP(ii)=errorStatsMAP(1);
      BER_ML(ii)=errorStatsML(1);
      
      reset(hErrorMAP);
      reset(hErrorML);
    end
    
    
    semilogy(EbN0dB,BER_MAP','ro-');
    hold on
    semilogy(EbN0dB,BER_ML','bx-');