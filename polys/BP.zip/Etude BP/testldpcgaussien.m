close all;
clear all;


%%%%%%%%%
%LDPC Parameters
%%%%%%%%%%%%%%%%%%%%%%
R=1/2;
%H = dvbs2ldpc(1/2);
load('S_IRA_N4096.mat');
H=H_prime;
H(1,4096)=0;
spy(H);   % Visualize the location of nonzero elements in H.
henc = fec.ldpcenc(H);
hdec = fec.ldpcdec(H);
itermax=50;
iterstep=50;
LLRmax=30;
CtoV=double(H);
nz=nnz(H);
[M,N]=size(H);
%modem
modulateur=modem.qammod('M', 4,'SymbolOrder', 'Gray','InputType','bit'); % note that default

%awgn channel
SNRrange=(0:0.25:2);
FER=zeros(1,length(SNRrange));
ii=1;
for SNRdb=SNRrange;

esno=10^(SNRdb/10);
Es=mean(abs(modulateur.Constellation.^2));
sig2=Es/esno;
teb=0;
demodulateur = modem.qamdemod('M',4,'SymbolOrder','Gray','OutputType', 'bit', 'DecisionType','llr','NoiseVariance',sig2);
mc=0;
MC=10000;

while (FER(ii)<100)&&(mc<(MC+1))
SNRdb, mc
%msg = randint(1,henc.NumInfoBits,2);  
msg = zeros(1,henc.NumInfoBits);
codeword = encode(henc,msg);
modulatedsig=modulate(modulateur,codeword.');
b=sqrt(sig2/2)*(randn(1,length(modulatedsig))+1i*randn(1,length(modulatedsig)));
y=modulatedsig+b.';

%initialisation

%CtoVinit=zeros(nz,1);
Lch=demodulate(demodulateur, y);
iter=0;
paritychecks=1;
while (sum(paritychecks)~=0) && (iter<itermax)
[APPllr,CtoV,iter]=myBPdecoder(Lch,CtoV,H,iterstep, iter);
cw=(1-sign(APPllr))/2;
errors=sum(cw(1:end/2));

paritychecks = mod(H* cw', 2);
end
iter
teb=teb+errors;
if errors
   FER(ii)=FER(ii)+1;
end
mc=mc+1;
end


FER(ii)=FER(ii)/mc
perf(ii)=teb/mc/(N/2)
ii=ii+1;

end
FER
