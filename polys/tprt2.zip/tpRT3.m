%Turbo codes
clear all;
%Simulation parameters
    EbN0dB=[0:0.25:2.5];
    N= 512;
    M=2;
    MC=10000;
    ITERMAX=15;
     %Interleaver
    s = RandStream('mt19937ar', 'Seed', 11);
    intrlvrIndices = randperm(s, N);
    hTEnc  = comm.TurboEncoder('TrellisStructure', poly2trellis(5, ...
             [37 21], 37), 'InterleaverIndices', intrlvrIndices);
    hMod   = comm.BPSKModulator;
    R=1/3;
    
    
       %handling errour count       
    hErrorMAP = comm.ErrorRate;
    
    %Allocation
    BER_MAP=zeros(ITERMAX,length(EbN0dB));
    for nbiter=1:ITERMAX
   
    
    %Coding parameters
    
    hTDec  = comm.TurboDecoder('TrellisStructure', poly2trellis(5, ...
             [37 21], 37), 'InterleaverIndices', intrlvrIndices, ...
             'NumIterations', nbiter);
    
    
   
    
    for ii=1:length(EbN0dB)
      
      
      %for mc=1:MC
      mc=0;
      NbErrors=0;
      
      while ((NbErrors <100)||(mc<1000))&&(mc<MC)    
      disp([ii,mc])
           
      %encode turbo codes
      data = randi(s, [0 1], N, 1);
      encodedData = step(hTEnc, data);
      modSignal = step(hMod, encodedData);
      
      %add noise
       EbN0=10^(EbN0dB(ii)/10);
       Px= mean(abs(modSignal).^2);
       sigma_2= Px/(2*log2(M)*R*(EbN0));
       noiseAWGN= sqrt(sigma_2)*randn(1,length(modSignal));
       receivedSignal = modSignal + noiseAWGN.';
      
      
      % Convert received signal to log-likelihood ratios for decoding
      receivedBits  = step(hTDec, (-2/sigma_2)*real(receivedSignal));
      
      %Demod
      % Convert soft decisions to hard decisions
      errorStatsMAP = step(hErrorMAP, data, receivedBits);
      mc=mc+1;
      NbErrors=errorStatsMAP(2);
      end
      
      BER_MAP(nbiter,ii)=errorStatsMAP(1)
      
      reset(hErrorMAP);
     end
    semilogy(EbN0dB,BER_MAP(:,:)','ro-');
    
    end
    
    semilogy(EbN0dB,BER_MAP(1:5:end,:)','ro-');